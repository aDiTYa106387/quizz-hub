 $(".loader").delay(1000).fadeOut(1000);

    


    
