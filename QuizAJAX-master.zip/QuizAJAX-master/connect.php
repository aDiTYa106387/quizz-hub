<?php
$servername = "localhost";
$username = "root";
$password = "root";
$db_name = "quizAjax";


// $conn = mysqli_connect("$servername", "$username", "$password", "$db_name");
